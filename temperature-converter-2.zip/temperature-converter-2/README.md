# Temperature Converter

A simple yet effective temperature converter for hassle-free basic temperature conversions.

## Motivation

About a year ago, I started learning JS through a course and built a temperature converter as my first project.

Initially, I had put it on GitHub within my old website's repository, which used to be public. However, I've since made the website private. The other day, someone reminded me about this project, prompting me to go back and improve it. I wanted to see how much I've learned in the past year.

## Where can I see the old version?

The earlier iteration of this converter is accessible [here](https://github.com/Ushie/temperature-converter/tree/v1).
